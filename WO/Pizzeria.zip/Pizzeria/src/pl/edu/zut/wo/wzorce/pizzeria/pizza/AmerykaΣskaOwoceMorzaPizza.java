package pl.edu.zut.wo.wzorce.pizzeria.pizza;

public class AmerykańskaOwoceMorzaPizza extends Pizza{
    
}
