package pl.edu.zut.wo.wzorce.pizzeria.pizza;

public class AmerykańskaWegetariańskaPizza extends Pizza{
    
}
