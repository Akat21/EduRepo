package pl.edu.zut.wo.wzorce.pizzeria.pizza;

public class Pizza {

	public void przygotowanie() {
		System.out.println("Przygotowanie: formowanie ciasta i układanie składników");
	}

	public void pieczenie() {
		System.out.println("Pieczenie: 25 minut w temperaturze 180 stopni Celsjusza");
	}

	public void krojenie() {
		System.out.println("Krojenie pizzy na 8 kawałków");
	}

	public void pakowanie() {
		System.out.println("Pakowanie pizzy w oficjalne pudełko naszej sieci Pizzerii.");
	}
	

}
