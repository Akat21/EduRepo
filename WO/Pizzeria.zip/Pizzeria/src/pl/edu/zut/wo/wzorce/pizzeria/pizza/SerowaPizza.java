package pl.edu.zut.wo.wzorce.pizzeria.pizza;

public class SerowaPizza extends Pizza {

}
