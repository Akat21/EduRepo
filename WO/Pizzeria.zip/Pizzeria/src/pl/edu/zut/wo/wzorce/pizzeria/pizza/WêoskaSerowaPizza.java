package pl.edu.zut.wo.wzorce.pizzeria.pizza;

public class WłoskaSerowaPizza extends Pizza{
    
}
