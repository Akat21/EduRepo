package pl.edu.zut.wo.wzorce.pizzeria.pizza;

public class WłoskaWegetariańskaPizza extends Pizza {
    
}
