package pl.edu.zut.wo.wzorce.pizzeria.składniki;

public class Cebula implements Warzywa {

}
