package pl.edu.zut.wo.wzorce.pizzeria.składniki;

public interface Małże {
    
}
