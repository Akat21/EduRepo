package pl.edu.zut.wo.wzorce.pizzeria.składniki;

public class SosMarinara implements Sos {

}
