package pl.edu.zut.wo.wzorce.pizzeria.składniki;

public class ŚwieżeMałże implements Małże {

}
