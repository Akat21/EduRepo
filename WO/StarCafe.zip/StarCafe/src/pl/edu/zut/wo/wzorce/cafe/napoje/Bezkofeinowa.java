package pl.edu.zut.wo.wzorce.cafe.napoje;

public class Bezkofeinowa extends Napój {
	public Bezkofeinowa() {
		opis = "Bezkofeinowa";
	}

	public double koszt() {
		return 2.0;
	}
}