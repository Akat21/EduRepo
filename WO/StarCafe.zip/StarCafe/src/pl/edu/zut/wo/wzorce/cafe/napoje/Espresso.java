package pl.edu.zut.wo.wzorce.cafe.napoje;

public class Espresso extends Napój {
    public Espresso(){
        opis = "Kawa Espresso";
    }

    public double koszt(){
        return 1.99;
    }
}
