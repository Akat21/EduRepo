package pl.edu.zut.wo.wzorce.cafe.napoje;

public class MocnoPalona extends Napój {

	public MocnoPalona() {
		opis = "Kawa Mocno Palona";
	}

	public double koszt() {
		return 0.99;
	}
}