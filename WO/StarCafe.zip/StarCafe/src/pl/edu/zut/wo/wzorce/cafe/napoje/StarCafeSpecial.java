package pl.edu.zut.wo.wzorce.cafe.napoje;

public class StarCafeSpecial extends Napój {
	public StarCafeSpecial() {
		opis = "Kawa Star Cafe Special";
	}

	public double koszt() {
		return 0.89;
	}
}