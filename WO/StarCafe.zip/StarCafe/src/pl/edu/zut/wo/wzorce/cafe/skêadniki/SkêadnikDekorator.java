package pl.edu.zut.wo.wzorce.cafe.składniki;

import pl.edu.zut.wo.wzorce.cafe.napoje.Napój;

public abstract class SkładnikDekorator extends Napój {
    public abstract String pobierzOpis();
}
